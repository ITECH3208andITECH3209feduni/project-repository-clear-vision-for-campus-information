<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_name = isset($_SESSION['name']) ? $_SESSION['name'] : 'Guest';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IIE (International Institute Of Education) | Home</title>
    <link rel="shortcut icon" href="images/icon.png" type="image/png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header>
        <div class="header-icons-container">
            <div class="header-icons">
                <!-- Staff Portal Icon -->
                <div class="icon">
                    <a href="staff-portal.html">
                        <i class="fas fa-users"></i>
                        <span>Staffs</span>
                    </a>
                </div>
                
                <!-- Student Portal Icon -->
                <div class="icon">
                    <a href="LogIn/index.php">
                        <i class="fas fa-user-graduate"></i>
                        <span>Students</span>
                    </a>
                </div>
                
                <!-- Campus Map Icon -->
                <div class="icon">
                    <a href="https://viewer.mapme.com/ceee2501-6bba-4407-88e5-5edab0fce542" target="_blank">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Location</span>
                    </a>
                </div>
                
                <!-- Search Bar -->
                <div class="search-bar">
                    <input type="text" id="searchInput" placeholder="Search...">
                    <button type="button" id="searchButton">Search</button>
                </div>
            </div>
        </div>
    </header>

<nav class="navbar">
    <div class="nav-container">
        <div class="logo">
            <a href="index.php"><img src="../Updated/images/logo.png" alt="IIE Logo"></a>
        </div>
        <div class="hamburger-menu" id="hamburger-menu">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
        <ul class="menu" id="menu">
            <li><a href="index.php">Home</a></li>
            <li class="dropdown">
                <a href="aboutus.php">About Us</a>
            </li>
            <li><a href="events.php">Events</a></li>
            <li class="dropdown">
                <a href="courses.html">Courses</a>
            </li>
            <li class="dropdown">
                <a href="#">Resources</a>
                <div class="dropdown-content">
                    <a href="handbook.html">Handbook</a>
                    <a href="student-portal-login.html">Student Portal Login</a>
                    <a href="../../Resource Booking/index.php">E-Resources</a>
                    <a href="overseas-student-health-cover.html">Overseas Student Health Cover</a>
                    <a href="service-and-facility.html">Service And Facility</a>
                    <a href="living-in-australia.html">Living In Australia</a>
                    <a href="payment-options.html">Payment Options</a>
                    <a href="study-pay-payment-plan.html">Study Pay Payment Plan</a>
                </div>
            </li>
            <li><a href="contact.html">Contact Us</a></li>
        </ul>
    </div>
</nav>