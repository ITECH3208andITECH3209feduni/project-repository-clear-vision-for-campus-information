<?php
include 'db.php';
$resource_id = $_GET['resource_id'];

$bookings_sql = "SELECT b.id, u.name, b.start_time, b.end_time, b.quantity 
                 FROM bookings b 
                 JOIN users u ON b.user_id = u.id 
                 WHERE b.resource_id = ? AND b.status = 'booked'
                 ORDER BY b.start_time DESC
                 LIMIT 50";
$stmt = $conn->prepare($bookings_sql);
$stmt->bind_param("i", $resource_id);
$stmt->execute();
$bookings_result = $stmt->get_result();

echo '<table class="booked-slots-table">';
echo '<thead><tr><th>User</th><th>Start Date/Time</th><th>End Date/Time</th><th>Quantity</th><th>Action</th></tr></thead>';
echo '<tbody>';
if ($bookings_result->num_rows > 0) {
    while ($slot = $bookings_result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $slot['name'] . '</td>';
        echo '<td>' . $slot['start_time'] . '</td>';
        echo '<td>' . $slot['end_time'] . '</td>';
        echo '<td>' . $slot['quantity'] . '</td>';
        echo '<td>';
        // Add conditional action buttons here
        echo '</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="5">No bookings found.</td></tr>';
}
echo '</tbody></table>';
?>
