// Example: Client-side form validation
document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');

    form.addEventListener('submit', (e) => {
        const startTime = new Date(form.start_time.value);
        const endTime = new Date(form.end_time.value);

        if (startTime >= endTime) {
            alert('End time must be after start time');
            e.preventDefault();
        }
    });
});
