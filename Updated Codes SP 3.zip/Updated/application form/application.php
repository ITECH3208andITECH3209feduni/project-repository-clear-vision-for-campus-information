<?php
include 'db_conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $middle_initial = $_POST['middle_initial'];
    $last_name = $_POST['last_name'];
    $birth_month = $_POST['birth_month'];
    $birth_day = $_POST['birth_day'];
    $birth_year = $_POST['birth_year'];
    $gender = $_POST['gender'];
    $citizenship = $_POST['citizenship'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $street_address = $_POST['street_address'];
    $street_address_line2 = $_POST['street_address_line2'];
    $city = $_POST['city'];
    $state_province = $_POST['state_province'];
    $postal_zip_code = $_POST['postal_zip_code'];
    $emergency_first_name = $_POST['emergency_first_name'];
    $emergency_last_name = $_POST['emergency_last_name'];
    $relationship = $_POST['relationship'];
    $emergency_email = $_POST['emergency_email'];
    $emergency_phone = $_POST['emergency_phone'];
    $other_languages = $_POST['other_languages'];

    // Insert personal information
    $sql_personal = "INSERT INTO personal_information (email, first_name, middle_initial, last_name, birth_month, birth_day, birth_year, gender, citizenship, phone, street_address, street_address_line2, city, state_province, postal_zip_code) 
                     VALUES ('$email', '$first_name', '$middle_initial', '$last_name', '$birth_month', '$birth_day', '$birth_year', '$gender', '$citizenship', '$phone', '$street_address', '$street_address_line2', '$city', '$state_province', '$postal_zip_code')";

    // Insert additional information
    $sql_additional = "INSERT INTO additional_information (email, emergency_first_name, emergency_last_name, relationship, emergency_email, emergency_phone, other_languages) 
                       VALUES ('$email', '$emergency_first_name', '$emergency_last_name', '$relationship', '$emergency_email', '$emergency_phone', '$other_languages')";

    if (mysqli_query($conn, $sql_personal) && mysqli_query($conn, $sql_additional)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql_personal . "<br>" . mysqli_error($conn);
        echo "Error: " . $sql_additional . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Invalid request method.";
}
?>
