<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eb1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['event_id'])) {
    $event_id = intval($_GET['event_id']);

    $sql = "SELECT id, name, date, location, time, description, available_seats FROM events WHERE id = $event_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $event = $result->fetch_assoc();
    } else {
        die("Event not found.");
    }
} else {
    die("No event specified.");
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Event</title>
    <link rel="shortcut icon" href="images/icon.png" type="image/png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> 
    <style>
        .booking-container {
            width: 80%;
            margin-top: 10px;
            margin-left: 30px;
            padding: 40px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
            margin-bottom: 10px;
        }
        .booking-container h1 {
            text-align: center;
        }
        .booking-container form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .booking-container input[type='text'],
        .booking-container input[type='email'] {
            padding: 10px;
            font-size: 1em;
        }
        .booking-container input[type='submit'] {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            font-size: 1em;
        }
        .booking-container input[type='submit']:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-icons-container">
            <div class="header-icons">
                <!-- Staff Portal Icon -->
                <div class="icon">
                    <a href="staff-portal.html">
                        <i class="fas fa-users"></i>
                        <span>Staffs</span>
                    </a>
                </div>
                
                <!-- Student Portal Icon -->
                <div class="icon">
                    <a href="student-portal.html">
                        <i class="fas fa-user-graduate"></i>
                        <span>Students</span>
                    </a>
                </div>
                
                <!-- Campus Map Icon -->
                <div class="icon">
                    <a href="https://viewer.mapme.com/ceee2501-6bba-4407-88e5-5edab0fce542" target="_blank">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Location</span>
                    </a>
                </div>
                
                <!-- Search Bar -->
                <div class="search-bar">
                    <input type="text" id="searchInput" placeholder="Search...">
                    <button type="button" id="searchButton">Search</button>
                </div>
            </div>
        </div>
    </header>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="index.html"><img src="images/logo.png" alt="IIE Logo"></a>
            </div>
            <div class="hamburger-menu">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
            </div>
            <ul class="menu">
                <li><a href="index.html">Home</a></li>
                <li class="dropdown">
                    <a href="#">About Us</a>
                    <div class="dropdown-content">
                        <a href="welcome.html">Welcome Message</a>
                        <a href="why-study-at-iie.html">Why Study At IIE?</a>
                        <a href="our-values.html">Our Values</a>
                        <a href="representatives.html">Representatives</a>
                        <a href="contact.html">Contact</a>
                    </div>
                </li>
                <li><a href="events.html">Events</a></li>
                <li class="dropdown">
                    <a href="index.php">Courses</a>
                    <div class="dropdown-content">
                        <div class="submenu">
                            <a href="international-courses.html">International Student</a>
                            <div class="submenu-content">
                                <a href="#">Accounting</a>
                                <a href="#">Community Service</a>
                                <a href="#">Early Childhood Education</a>
                                <a href="#">Health And Science</a>
                                <a href="#">Hospitality Management</a>
                                <a href="#">Information Technology</a>
                                <a href="#">Management</a>
                            </div>
                        </div>
                        <div class="submenu">
                            <a href="domestic-courses.html">Domestic Student</a>
                            <div class="submenu-content">
                                <a href="#">Accounting</a>
                                <a href="#">Community Services</a>
                                <a href="#">Early Childhood Education</a>
                                <a href="#">Health And Science</a>
                                <a href="#">Hospitality Management</a>
                                <a href="#">Information Technology</a>
                                <a href="#">Management</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="dropdown">
                    <a href="#">Resources</a>
                    <div class="dropdown-content">
                        <a href="handbook.html">Handbook</a>
                        <a href="student-portal-login.html">Student Portal Login</a>
                        <a href="e-learning.html">E-Learning</a>
                        <a href="overseas-student-health-cover.html">Overseas Student Health Cover</a>
                        <a href="service-and-facility.html">Service And Facility</a>
                        <a href="living-in-australia.html">Living In Australia</a>
                        <a href="payment-options.html">Payment Options</a>
                        <a href="study-pay-payment-plan.html">Study Pay Payment Plan</a>
                    </div>
                </li>
                <li><a href="contact.html">Contact Us</a></li>
            </ul>
        </div>
    </nav>

    <div class="booking-container">
        <h1>Book Event: <?php echo htmlspecialchars($event['name']); ?></h1>
        <p><strong>Date:</strong> <?php echo htmlspecialchars($event['date']); ?></p>
        <p><strong>Time:</strong> <?php echo htmlspecialchars($event['time']); ?></p>
        <p><strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?></p>
        <p><strong>Available seats:</strong> <span id="available-seats"><?php echo htmlspecialchars($event['available_seats']); ?></span></p>
        <form method="post" action="attend.php">
            <input type="hidden" name="event_id" value="<?php echo htmlspecialchars($event['id']); ?>">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <input type="text" name="phone" placeholder="Your Phone" required>
            <input type="submit" value="Book">
        </form>
    </div>

    <footer>
        <div class="container">
            <div class="footer-section contact-info">
                <h3>Contact Us</h3>
                <p>International Institute of Education- IIE</p>
                <p>Level 1 16-18 Wentworth Street, Parramatta, NSW, 2150, Australia</p>
                <p>Phone: +61 (02) 88972125</p>
                <p>Email: info@iie.edu.au</p>
            </div>
            
            <div class="footer-section useful-links">
                <h3>Useful Links</h3>
                <ul>
                    <li><a href="#">Department of Home Affairs</a></li>
                    <li><a href="#">Department of Education</a></li>
                    <li><a href="#">Study Australia</a></li>
                    <li><a href="#">ASQA</a></li>
                    <li><a href="#">Commonwealth Ombudsman</a></li>
                </ul>
            </div>
            
            <div class="footer-section about-us">
                <h3>About Us</h3>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Why Study at IIE?</a></li>
                    <li><a href="#">Our Values</a></li>
                    <li><a href="#">Representatives</a></li>
                </ul>
            </div>
            
            <div class="footer-section online-forms">
                <h3>Online Forms</h3>
                <ul>
                    <li><a href="#">Agent Application</a></li>
                    <li><a href="#">International Student Enrolment</a></li>
                    <li><a href="#">ID Card Request</a></li>
                    <li><a href="#">Refund Request Application</a></li>
                    <li><a href="#">Student Document Request Form</a></li>
                </ul>
            </div>
            
            <div class="footer-section additional-links">
                <h3>Additional Links</h3>
                <ul>
                    <li><a href="#">Staff Login</a></li>
                    <li><a href="#">Partner Login</a></li>
                </ul>
                <p>&copy; International Institute of Education | RTO No: 45150 CRICOS: 03838G |</p>
            </div>
        </div>
    </footer>
</body>
</html>
