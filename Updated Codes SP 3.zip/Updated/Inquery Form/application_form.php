<?php
// Include the database connection
require_once 'connection.php';

// Check if the form is submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form data
    $title = htmlspecialchars($_POST['title']);
    $existingStudentNumber = htmlspecialchars($_POST['existingStudentNumber']);
    $firstName = htmlspecialchars($_POST['firstName']);
    $lastName = htmlspecialchars($_POST['lastName']);
    $dateOfBirth = htmlspecialchars($_POST['dateOfBirth']);
    $gender = htmlspecialchars($_POST['gender']);
    $maritalStatus = htmlspecialchars($_POST['maritalStatus']);

    // Validate form data (perform more detailed validation as needed)
    if (empty($firstName) || empty($lastName) || empty($dateOfBirth)) {
        // Handle validation error (e.g., display error message and redirect)
        echo "Please fill out all required fields.";
        exit;
    }

    try {
        // Prepare SQL statement to insert applicant data into 'applicants' table
        $sql = "INSERT INTO applicants (Title, ExistingStudentNumber, FirstName, LastName, DateOfBirth, Gender, MaritalStatus) 
                VALUES (:title, :existingStudentNumber, :firstName, :lastName, :dateOfBirth, :gender, :maritalStatus)";
        $stmt = $pdo->prepare($sql);

        // Bind parameters and execute the statement
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':existingStudentNumber', $existingStudentNumber);
        $stmt->bindParam(':firstName', $firstName);
        $stmt->bindParam(':lastName', $lastName);
        $stmt->bindParam(':dateOfBirth', $dateOfBirth);
        $stmt->bindParam(':gender', $gender);
        $stmt->bindParam(':maritalStatus', $maritalStatus);

        // Execute the SQL statement
        $stmt->execute();

        // Display success message or redirect to a success page
        echo "Application submitted successfully!";
    } catch (PDOException $e) {
        // Display error message if database operation fails
        echo "Error: " . $e->getMessage();
    }
} else {
    // Redirect or display an error message if the form is not submitted via POST
    echo "Invalid request method.";
}
?>
