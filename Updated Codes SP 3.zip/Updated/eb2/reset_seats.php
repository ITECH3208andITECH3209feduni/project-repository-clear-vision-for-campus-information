<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eb1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Reset available seats based on initial total seats for each event
$resetSeatsSql = "UPDATE events SET available_seats = CASE
    WHEN name = 'Astrophysics' THEN 45
    WHEN name = 'Food Festival' THEN 35
    WHEN name = 'Basketball Tournament' THEN 5
    ELSE available_seats
END";
if ($conn->query($resetSeatsSql) === TRUE) {
    echo "Seats reset to initial values.<br>";
} else {
    echo "Error resetting seats: " . $conn->error . "<br>";
}

// Adjust available seats based on current bookings
$adjustSeatsSql = "UPDATE events e
                   JOIN (
                     SELECT event_id, COUNT(*) AS booked_seats
                     FROM bookings
                     GROUP BY event_id
                   ) b ON e.id = b.event_id
                   SET e.available_seats = CASE
                        WHEN e.name = 'Astrophysics' THEN 45 - b.booked_seats
                        WHEN e.name = 'Food Festival' THEN 35 - b.booked_seats
                        WHEN e.name = 'Basketball Tournament' THEN 5 - b.booked_seats
                        ELSE e.available_seats
                   ";
if ($conn->query($adjustSeatsSql) === TRUE) {
    echo "Seats updated based on current bookings.";
} else {
    echo "Error updating seats: " . $conn->error;
}

$conn->close();
?>
