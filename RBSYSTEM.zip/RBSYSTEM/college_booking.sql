-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2024 at 03:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'booked',
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `resource_id`, `user_id`, `start_time`, `end_time`, `status`, `quantity`) VALUES
(36, 19, 6, '2024-08-02 12:00:00', '2024-08-02 13:15:00', 'expired', 1),
(42, 18, 6, '2024-08-06 12:00:00', '2024-08-06 14:00:00', 'expired', 1),
(43, 18, 6, '2024-08-06 22:00:00', '2024-08-06 23:00:00', 'expired', 1),
(51, 18, 6, '2024-08-07 12:00:00', '2024-08-07 16:00:00', 'booked', 1),
(52, 23, 6, '2024-08-07 12:00:00', '2024-08-15 12:00:00', 'booked', 1),
(54, 18, 7, '2024-08-08 12:00:00', '2024-08-08 17:00:00', 'booked', 1);

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`id`, `name`, `type`, `quantity`, `description`, `type_id`, `image`) VALUES
(18, 'Class 1', 'classroom', 5, 'Classroom for Arts.', NULL, 'art.jpg'),
(19, 'Lab 1', 'lab', 5, 'Computer Lab 1', NULL, 'IT.jpg'),
(20, 'Lab 2', 'lab', 6, 'Computer Lab 2', NULL, 'IT.jpg'),
(21, 'Headset 1', 'equipment', 10, 'Experience clear video calls with a simple USB connection and a noise-canceling mic. In-line controls to adjust volume or mute without interrupting calls. Fine-tuned drivers for enhanced digital audio.', NULL, 'headset1.jpg'),
(22, 'Headset 2', 'equipment', 5, 'Experience clear video calls with a simple USB connection. Fine-tuned drivers for enhanced digital audio.', NULL, 'headset2.jpg'),
(23, 'Class 2', 'classroom', 5, 'Classroom for Physics.\r\n', NULL, 'physics.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `resource_types`
--

CREATE TABLE `resource_types` (
  `id` int(11) NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `profile_pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `role`, `profile_pic`) VALUES
(5, 'Anand', 'panthianand49@gmail.com', '$2y$10$j9tOZlEJt8ZdfSeW5gpNduTq0jR1QzYQrJUGLGWvyTEkWG.h9ZIHu', 'student', 'uploads/image2.jpg'),
(6, 'Abbas Shiek', 'abbasshiek23@gmail.com', '$2y$10$VawqeLaLNGZjRHliHMhKBOMQi1AUq9PLaoSHf45k0jdlwxeHHRYfe', 'staff', 'uploads/image3.jpg'),
(7, 'Bibek', 'bibekabc123@gmail.com', '$2y$10$gIW9MLXzQ1icqJnex9KBh.iCjAlPPdoeIKnVvx.KflW6twWRGSyN2', 'staff', 'uploads/chewy.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `resource_id` (`resource_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_type_id` (`type_id`);

--
-- Indexes for table `resource_types`
--
ALTER TABLE `resource_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type_name` (`type_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `resource_types`
--
ALTER TABLE `resource_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resources` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `resources`
--
ALTER TABLE `resources`
  ADD CONSTRAINT `fk_type_id` FOREIGN KEY (`type_id`) REFERENCES `resource_types` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
