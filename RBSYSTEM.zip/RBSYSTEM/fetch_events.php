<?php
include 'db.php';

$resource_id = $_GET['resource_id'];

$events = [];

$bookings_sql = "SELECT start_time, end_time FROM bookings 
                 WHERE resource_id = $resource_id AND status = 'booked'";
$bookings_result = $conn->query($bookings_sql);

if ($bookings_result->num_rows > 0) {
    while ($row = $bookings_result->fetch_assoc()) {
        $events[] = [
            'title' => 'Booked',
            'start' => $row['start_time'],
            'end' => $row['end_time'],
            'backgroundColor' => '#ff0000', // red for booked
            'borderColor' => '#ff0000', // red border for booked
        ];
    }
}

echo json_encode($events);
?>
