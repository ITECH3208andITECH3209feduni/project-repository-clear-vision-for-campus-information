<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['resource_id'])) {
    echo "Resource not found or invalid request.";
    exit();
}

$resource_id = $_GET['resource_id'];

$sql = "SELECT * FROM resources WHERE id = $resource_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "Resource not found or invalid request.";
    exit();
}

$resource = $result->fetch_assoc();

$success_message = "";
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['start_time']) || empty($_POST['end_time'])) {
        $error_message = "Both start time and end time are required.";
    } else {
        $start_time = $_POST['start_time'];
        $end_time = $_POST['end_time'];
        $user_id = $_SESSION['user_id'];

        // Check if end time is after start time
        if (strtotime($end_time) <= strtotime($start_time)) {
            $error_message = "End time must be after start time.";
        } else {
            // Check for overlapping bookings
            $overlap_check_sql = "SELECT COUNT(*) as overlap_count FROM bookings 
                                  WHERE resource_id = $resource_id AND status = 'booked'
                                  AND (
                                      (start_time <= '$start_time' AND end_time > '$start_time') OR
                                      (start_time < '$end_time' AND end_time >= '$end_time') OR
                                      (start_time >= '$start_time' AND end_time <= '$end_time')
                                  )";
            $overlap_check_result = $conn->query($overlap_check_sql);
            $overlap_count = $overlap_check_result->fetch_assoc()['overlap_count'];

            if ($overlap_count > 0) {
                $error_message = "The selected time slot is already booked.";
            } else {
                $booking_sql = "INSERT INTO bookings (resource_id, user_id, start_time, end_time, status) 
                                VALUES ('$resource_id', '$user_id', '$start_time', '$end_time', 'booked')";
                if ($conn->query($booking_sql) === TRUE) {
                    $success_message = "Booking successful!";
                    echo '<script>
                        setTimeout(function() {
                            window.location.href = "index.php";
                        }, 1000); // Redirect after 1 second
                    </script>';
                } else {
                    $error_message = "Error: " . $booking_sql . "<br>" . $conn->error;
                }
            }
        }
    }
}

$bookings_sql = "SELECT b.id, u.name, b.start_time, b.end_time, b.user_id
                 FROM bookings b 
                 JOIN users u ON b.user_id = u.id 
                 WHERE b.resource_id = $resource_id AND b.status = 'booked'";
$bookings_result = $conn->query($bookings_sql);
$booked_slots = [];
if ($bookings_result->num_rows > 0) {
    while($booking = $bookings_result->fetch_assoc()) {
        $booked_slots[] = $booking;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Resource</title>
    <link rel="stylesheet" href="rbstyle.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body>
    <div class="form-container">
        <h1>Book Resource: <?php echo $resource['name']; ?></h1>
        <?php if (!empty($error_message)): ?>
            <div class="message error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($success_message)): ?>
            <div class="message success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <form method="POST" action="" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="start_time">Start Time:</label>
                <input type="text" id="start_time" name="start_time" required>
            </div>
            <div class="form-group">
                <label for="end_time">End Time:</label>
                <input type="text" id="end_time" name="end_time" required>
            </div>
            <button type="submit" class="btn">Book</button>
        </form>
        <h2>Booked Slots:</h2>
        <table class="booked-slots-table">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Start Date/Time</th>
                    <th>End Date/Time</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($booked_slots as $slot): ?>
                    <tr>
                        <td><?php echo $slot['name']; ?></td>
                        <td><?php echo $slot['start_time']; ?></td>
                        <td><?php echo $slot['end_time']; ?></td>
                        <td>
                            <?php if ($slot['user_id'] == $_SESSION['user_id']): ?>
                                <form method="POST" action="delete_booking.php">
                                    <input type="hidden" name="booking_id" value="<?php echo $slot['id']; ?>">
                                    <button type="submit" class="btn delete-btn">Delete</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        flatpickr("#start_time", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            minDate: "today",
            disable: [
                <?php foreach($booked_slots as $slot): ?>
                    {
                        from: "<?php echo $slot['start_time']; ?>",
                        to: "<?php echo $slot['end_time']; ?>"
                    },
                <?php endforeach; ?>
            ]
        });
        flatpickr("#end_time", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            minDate: "today",
            disable: [
                <?php foreach($booked_slots as $slot): ?>
                    {
                        from: "<?php echo $slot['start_time']; ?>",
                        to: "<?php echo $slot['end_time']; ?>"
                    },
                <?php endforeach; ?>
            ]
        });

        function validateForm() {
            var startTime = document.getElementById('start_time').value;
            var endTime = document.getElementById('end_time').value;

            if (startTime === '' || endTime === '') {
                alert('Both start time and end time are required.');
                return false;
            }

            if (new Date(startTime) >= new Date(endTime)) {
                alert('End time must be after start time.');
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
