<?php
include 'db.php';
$resource_id = $_GET['resource_id'];

$disabled_dates_sql = "SELECT start_time, end_time FROM bookings 
                       WHERE resource_id = ? AND status = 'booked'";
$stmt = $conn->prepare($disabled_dates_sql);
$stmt->bind_param("i", $resource_id);
$stmt->execute();
$result = $stmt->get_result();

$disabled_dates = [];
while ($row = $result->fetch_assoc()) {
    $disabled_dates[] = [
        'from' => $row['start_time'],
        'to' => $row['end_time']
    ];
}

echo json_encode($disabled_dates);
?>
