<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = $_POST['booking_id'];
    $user_id = $_SESSION['user_id'];

    $sql = "DELETE FROM bookings WHERE id = $booking_id AND user_id = $user_id";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = "Booking deleted successfully!";
    } else {
        $_SESSION['error'] = "Error: " . $conn->error;
    }
}

header("Location: index.php");
exit();
?>
