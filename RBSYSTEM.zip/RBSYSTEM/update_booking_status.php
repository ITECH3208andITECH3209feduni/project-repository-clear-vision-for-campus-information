<?php
include 'db.php';

$sql = "UPDATE bookings SET status = 'expired' WHERE end_time < NOW() AND status = 'booked'";
$conn->query($sql);
?>
