<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$name = $_SESSION['name'];
$user_name = $_SESSION['username']; // Retrieve the user's name from the session
$success = "";

if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>
<body>
    <main>
        <?php if ($success): ?>
            <p class="success"><?php echo $success; ?></p>
        <?php endif; ?>
        <h2>Welcome to the Resource Booking System</h2>
        <div class="container">
            <?php if ($role === 'staff'): ?>
                <div class="card">
                    <img src="images/classroom.jpg" alt="Classrooms">
                    <h2>Classrooms</h2>
                    <p>Book classrooms for your lectures and meetings.</p>
                    <a href="classes.php" class="btn">Go to Classrooms</a>
                </div>
            <?php endif; ?>
            <div class="card">
                <img src="images/lab.jpg" alt="Labs">
                <h2>Labs</h2>
                <p>Book labs for practical sessions and research.</p>
                <a href="labs.php" class="btn">Go to Labs</a>
            </div>
            <div class="card">
                <img src="images/equipment.jpg" alt="Equipment">
                <h2>Equipment</h2>
                <p>Book equipment for your projects and events.</p>
                <a href="equipment.php" class="btn">Go to Equipment</a>
            </div>
        </div>
    </main>
    <?php include 'footer.php'; ?>
    <script>
        
document.addEventListener('DOMContentLoaded', function() {
    const hamburgerMenu = document.getElementById('hamburger-menu');
    const menu = document.getElementById('menu');
    const submenuToggles = document.querySelectorAll('.submenu > a');

    // Toggle the menu visibility on small screens
    hamburgerMenu.addEventListener('click', function() {
        menu.classList.toggle('show');
        // Adjust main content position
        if (menu.classList.contains('show')) {
            document.querySelector('main').style.marginTop = '200px'; // Adjust this value as needed
        } else {
            document.querySelector('main').style.marginTop = '0';
        }
    });

    // Handle submenu toggles
    submenuToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(event) {
            event.preventDefault();
            const submenu = this.nextElementSibling;
            if (submenu.classList.contains('show')) {
                submenu.classList.remove('show');
            } else {
                // Hide other open submenus
                document.querySelectorAll('.submenu-content').forEach(function(openSubmenu) {
                    openSubmenu.classList.remove('show');
                });
                submenu.classList.add('show');
            }
        });
    });

    // Hide dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.dropdown')) {
            document.querySelectorAll('.dropdown-content').forEach(function(openDropdown) {
                openDropdown.style.display = 'none';
            });
        }
    });
});


</script>

</body>
</html>
