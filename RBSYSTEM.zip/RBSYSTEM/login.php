<?php
include 'db.php';
session_start();

$error = ""; // Initialize an empty error variable

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare the SQL query to prevent SQL injection
    $sql = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $sql->bind_param("s", $username);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            header("Location: index.php");
            exit(); // Always call exit after a redirect to stop script execution
        } else {
            $error = "Invalid password";
        }
    } else {
        $error = "No user found";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="rbstyle.css">
</head>
<body>
    <section class="elementor-section elementor-top-section elementor-element elementor-element-3beb773 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3beb773" data-element_type="section">
        <div class="elementor-background-overlay"></div>
        <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2ef04b8" data-id="2ef04b8" data-element_type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-a190333 elementor-widget elementor-widget-wp-widget-rev-slider-widget" data-id="a190333" data-element_type="widget" data-widget_type="wp-widget-wp-widget-rev-slider-widget.default">
                        <div class="elementor-widget-container">
                            <h1>Welcome to Our College</h1>
                            <p>Discover our programs and make your future brighter.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <div class="login-container">
        <img src="../../Updated/Images/logo.png" alt="College Logo" class="logo">
        <form action="login.php" method="post">
            <h2>LOGIN</h2>
            <!-- Display error message -->
            <?php if (!empty($error)): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
            <label>User Name</label>
            <input type="text" name="username" placeholder="User Name" required><br>
            <label>Password</label>
            <div class="password-wrapper">
                <input type="password" name="password" id="password" placeholder="Password" required>
                <span id="togglePassword" class="eye">👁️</span>
            </div>
            <button type="submit">Login</button>
        </form>
        <div class="forgot-password">
            <a href="forgot_password.php">Forgot Password?</a> <!-- Corrected link -->
        </div>
    </div>

    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function (e) {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.textContent = type === 'password' ? '👁️' : '🙈';
        });
    </script>
</body>
</html>
