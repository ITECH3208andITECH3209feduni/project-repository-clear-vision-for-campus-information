<?php
$page_title = 'IIE (International Institute Of Education) | About Us';
include 'header.php';
?>

<body>
    <div id="content">
    </div>

    <div class="about-us-container">
        <header class="about-header">
            <p class="quote">“An investment in knowledge pays the best interest.”</p>
            <p class="quote-author">- Benjamin Franklin</p>
        </header>
        <h1>Know Who We Are</h1>

        <img src="images/aboutus.jpg" alt="About Us" class="about-header-img">

        <section class="about-content">
            <p>First Choice Education Pty Ltd T/A International Institute of Education, RTO No: 45150 And CRICOS: 03838G is a Registered Training Organisation located at 16-18 Wentworth Street Parramatta NSW 2150.</p>
            <p>IIE operates under the VET Quality Framework. This is a regulated framework administered by the Australian Skills Quality Authority (ASQA). Our registration details are located on the National Register for VET and our qualifications are recognised under the Australian Qualifications Framework.</p>
            <p>As a registered training organisation delivering courses to international students, IIE is also required to maintain registration in compliance with the Education Services for Overseas Students Act 2000 (ESOS Act 2000) and The National Code of Practice for Providers of Education and Training to Overseas Students 2018 (National Code 2018).</p>
            <p>IIE offers courses in Early Childhood Education and Care, Accounting, Business, Information Technology, Hospitality, Community Service, Ageing Support, Disability, and Mental Health.</p>
        </section>
    </div>

    <?php include 'footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menuBtn = document.querySelector('.hamburger-menu');
            const menu = document.querySelector('.menu');

            menuBtn.addEventListener('click', function () {
                menu.classList.toggle('show');
            });
        });

        function loadContent(section) {
            const contentDiv = document.getElementById('content');
            const aboutUsContainer = document.querySelector('.about-us-container');

            // Hide the About Us container if section is not 'about-us'
            if (section === 'about-us') {
                aboutUsContainer.style.display = 'block';
            } else {
                aboutUsContainer.style.display = 'none';
            }
            contentDiv.innerHTML = '';

            switch (section) {
                case 'welcome':
                    contentDiv.innerHTML = `
                        <header class="about-header">
                            <h1>Welcome Message</h1>
                        </header>
                        <img src="images/welcome.jpg" alt="Welcome" class="why-iie-img">
                        <section class="about-content">
                            <p>Thank you for your interest in courses at International Institute Of Education. I’m delighted that you’ve taken the time to view our website and hope it may help you decide to make IIE your first choice when it comes to your future training needs. At IIE, we believe that we are unique.</p>
                            <p>The College is new and innovative with an enviable reputation as a provider of quality training in a caring environment. Whilst our students include individuals from almost every background, culture and belief, our focus on values makes us a little different from other colleges.</p>
                            <p>We are ethical in our dealings with students and stakeholders and every student is treated as an individual. As CEO, my door is always open to students, whether wishing to discuss the course, personal concerns or simply to pass the time of day. It’s true to say that at IIE, students are our number one priority.</p>
                            <p>We are all aware that today’s corporate world is a very competitive place and organisations are increasingly seeking employees with ‘the right attitude’. In an effort to address this, we focus on the whole individual, not just the skills needed for work. Our students are encouraged to develop and demonstrate an attitude that’s appealing to prospective employers.</p>
                            <p>This includes respect for others, honesty, integrity, loyalty and a strong work ethic. These attributes are important in our work life and also in our personal life – they help us to be successful individuals.</p>
                            <p class="ceo-signature">
                                <img src="images/ceo.png" alt="CEO Signature" class="ceo-signature-img">
                                Sagar Lohani (CEO IIE)
                            </p>
                        </section>
                    `;
                    break;
                case 'why-study':
                    contentDiv.innerHTML = `
                        <header class="about-header">
                            <h1>Why Study At IIE?</h1>
                        </header>
                        <img src="images/ss.jpg" alt="Why IIE" class="why-iie-img">
                        <section class="about-content">
                            <p>Some still see college and the eventual job you get as two separate entities. We don’t. At International Institute of Education, we work with both domestic and international students to ensure their studies lead to a satisfying and prosperous career, one that allows you to dream big and make a difference in this world.</p>
                            <p>We have focused on four stages “E” to accelerate our prospective learners; we have focused on designing our courses on that level where students will learn the latest industry-demand knowledge and will adopt industry-required skills. Our powerful four-stage Educate, Enable, Empower, and Employability-focused training process ensures potential employees will like what they see and get you started on the path to a satisfying career sooner.</p>
                            <h3>Educate</h3>
                            <p>Gain the critical knowledge you need to establish a career in a range of vocational courses. Our courses embrace the most relevant and up-to-date methods in use across the industry today. Carving out a dream career is one of the major reasons people come to education providers and at IIE we will work together to make it happen.</p>
                            <h3>Enable</h3>
                            <p>We encourage bold, independent thinking and offer the highest quality academic experience. At IIE you will be able to develop the practical skills, fresh thinking, and confidence increasingly in demand/expected by employers. Our latest industry-demand courses will enable you with industry-desired skills and increase employability.</p>
                            <h3>Empower</h3>
                            <p>Education does not only lead you to your better career but empowers you by encouraging leadership behaviors. At IIE our staff and tutors will work together with all of our students to provide ample opportunity to take charge, whether that’s through group activities or explaining a concept they’ve grasped to the rest of the class.</p>
                            <h3>Employability</h3>
                            <p>Some still see institution and the eventual job you get as two separate entities. We don’t. At IIE we work with our students to ensure your training leads you to a satisfying and prosperous career, one that allows you to dream big and make a difference around the globe. At IIE, we encourage you to dream big and make a difference in this world.</p>
                        </section>
                    `;
                    break;
                case 'values':
                    contentDiv.innerHTML = `
                        <header class="about-header">
                            <h1>Our Values</h1>
                        </header>
                        <section class="values-content">
                            <div class="value-item">
                                <img src="images/relationship.jpg" alt="Relationships" class="value-img">
                                <div class="value-text">
                                    <h3>Relationships</h3>
                                    <p>Creative, respectful relationships are the platform for our learning. Client relationships are developed around honest exchange and commitment to shared goals.</p>
                                    <p><strong>In Practice:</strong> We build effective, mutually rewarding relationships with clients, students, other providers, and government.​</p>
                                </div>
                            </div>
                            <div class="value-item">
                                <img src="images/achievement.jpg" alt="Achievement" class="value-img">
                                <div class="value-text">
                                    <h3>Achievement</h3>
                                    <p>Learning must link to achievement and contribution. Training must challenge the individual, and thus build confidence.</p>
                                    <p><strong>In Practice:</strong> We will be courageous when exploring possibilities – learning from experience is a reward.</p>
                                </div>
                            </div>
                            <div class="value-item">
                                <img src="images/creating-value.jpg" alt="Creating Value" class="value-img">
                                <div class="value-text">
                                    <h3>Creating Value</h3>
                                    <p>Learning creates employment opportunities for people and groups. Current industry knowledge is an essential and vital resource.</p>
                                    <p><strong>In Practice:</strong> We ensure every client, corporation or individual leaves IIE feeling they have gained from the experience. We strive to be experts in our field.</p>
                                </div>
                            </div>
                            <div class="value-item">
                                <img src="images/leadership-learning.jpg" alt="Leadership & Learning" class="value-img">
                                <div class="value-text">
                                    <h3>Leadership & Learning</h3>
                                    <p>Lead by action – IIE has to set training benchmarks, not just follow others. There is no substitute for working hard to get things right the first time.</p>
                                    <p><strong>In Practice:</strong> We do the hard work and make every product, every presentation, first class.</p>
                                </div>
                            </div>
                            <div class="value-item">
                                <img src="images/honesty.jpg" alt="Honesty" class="value-img">
                                <div class="value-text">
                                    <h3>Honesty</h3>
                                    <p>Say it as it is but always with respect.</p>
                                    <p><strong>In Practice:</strong> We name problems and accept them, then find solutions with those involved.</p>
                                </div>
                            </div>
                            <div class="value-item">
                                <img src="images/responsibility.jpg" alt="Responsibility" class="value-img">
                                <div class="value-text">
                                    <h3>Responsibility</h3>
                                    <p>Creating a future for our planet with an environmental commitment and embracing social responsibility. There is no substitute for working hard to get things right the first time.</p>
                                    <p><strong>In Practice:</strong> We apply environmental awareness to decision-making, recycling, and using environmentally aware practices in our offices and training rooms. We seek opportunities to support the communities in which we have a presence.</p>
                                </div>
                            </div>
                        </section>
                    `;
                    break;
                case 'representatives':
                    contentDiv.innerHTML = `
                        <header class="about-header">
                            <h1>Our Representatives</h1>
                            <p>"Introducing the faces behind our success—meet our dedicated representatives who are committed to guiding you every step of the way!"</p>
                        </header>
                        <div class="representatives-section">
                            <div class="rep-card">
                                <img src="images/representative1.jpg" alt="Sudeep Acharya" class="rep-image">
                                <div class="rep-name">Sudeep Acharya</div>
                                <div class="rep-contact">
                                    <p>Contact: Sudeep Acharya</p>
                                    <p>Phone: +61 426 992 880</p>
                                    <p>Mobile: +61 426 992 880</p>
                                    <p>Email: sudeep.acharya@thecanbrand.com</p>
                                </div>
                            </div>
                            <div class="rep-card">
                                <img src="images/representative2.jpg" alt="Anand Yadav" class="rep-image">
                                <div class="rep-name">Anand Yadav</div>
                                <div class="rep-contact">
                                    <p>Contact: Sunil Panta</p>
                                    <p>Phone: 0392255213</p>
                                    <p>Mobile: 0415865203</p>
                                    <p>Email: sunil@brillianteduaustralia.com</p>
                                </div>
                            </div>
                            <div class="rep-card">
                                <img src="images/representative-placeholder.png" alt="UTSAB POKHAREL" class="rep-image">
                                <h3 class="rep-name">UTSAB POKHAREL</h3>
                                <p class="rep-contact">
                                    <strong>Company:</strong> THREE ENTERPRISE PTY LTD<br>
                                    <strong>Contact:</strong> UTSAB POKHAREL<br>
                                    <strong>Phone:</strong> 0412 241 000<br>
                                    <strong>Mobile:</strong> 0412 241 000<br>
                                    <p>Email: sunil@brillianteduaustralia.com</p>
                                </p>
                            </div>
                            <div class="rep-card">
                                <img src="images/representative-placeholder.png" alt="Surya Khanal" class="rep-image">
                                <h3 class="rep-name">Surya Khanal</h3>
                                <p class="rep-contact">
                                    <strong>Company:</strong> MG ASSOCIATES PTY LTD<br>
                                    <strong>Contact:</strong> Surya Khanal<br>
                                    <strong>Phone:</strong> + 61 2 9008 5522<br>
                                    <strong>Mobile:</strong> + 61 2 9008 5522<br>
                                    <p>Email: info@mgassociates.com.au</p>
                                </p>
                            </div>
                            <div class="rep-card">
                                <img src="images/representative-placeholder.png" alt="Komal Raj Pathak" class="rep-image">
                                <h3 class="rep-name">Komal Raj Pathak</h3>
                                <p class="rep-contact">
                                    <strong>Company:</strong> 4Nations Group Pty Ltd<br>
                                    <strong>Contact:</strong> Komal Raj Pathak<br>
                                    <strong>Phone:</strong> +61 2 9267 3660<br>
                                    <strong>Mobile:</strong> +61 450 686 144<br>
                                    <p>Email: komal.pathak@4nations.com.au</p>
                                </p>
                            </div>
                            <div class="rep-card">
                                <img src="images/representative-placeholder.png" alt="Hetal Nayak" class="rep-image">
                                <h3 class="rep-name">Hetal Nayak</h3>
                                <p class="rep-contact">
                                    <strong>Company:</strong> PRUDENTIAL INTERNATIONAL<br>
                                    <strong>Contact:</strong> Hetal Nayak<br>
                                    <strong>Phone:</strong> 0414278073<br>
                                    <strong>Mobile:</strong> 0414278073<br>
                                    <p>Email: offerprud@gmail.com</p>
                                </p>
                            </div>
                        </div>
                    `;
                    break;
                case 'contact':
                    contentDiv.innerHTML = `<h2>Contact</h2><p>Contact us at...</p>`;
                    break;
                default:
                    contentDiv.innerHTML = `<p>Content not found.</p>`;
            }
        }
    </script>
</body>
</html>
