<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="loginstyle.css">
</head>
<body>
    <section class="elementor-section elementor-top-section elementor-element elementor-element-3beb773 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3beb773" data-element_type="section">
        <div class="elementor-background-overlay"></div>
        <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2ef04b8" data-id="2ef04b8" data-element_type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-a190333 elementor-widget elementor-widget-wp-widget-rev-slider-widget" data-id="a190333" data-element_type="widget" data-widget_type="wp-widget-wp-widget-rev-slider-widget.default">
                        <div class="elementor-widget-container">
                            <h1>Welcome to Our College</h1>
                            <p>Discover our programs and make your future brighter.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <div class="container">
        <img src="logo.png" alt="College Logo" class="logo">
        <form action="login.php" method="post">
            <h2>LOGIN</h2>
            <?php if (isset($_GET['error'])) { ?>
                <p class="error"><?php echo $_GET['error']; ?></p>
            <?php } ?>
            <label>User Name</label>
            <input type="text" name="uname" placeholder="User Name"><br>
            <label>Password</label>
            <div class="password-wrapper">
                <input type="password" name="password" id="password" placeholder="Password">
                <span id="togglePassword" class="eye">👁️</span>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>

    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function (e) {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.textContent = type === 'password' ? '👁️' : '🙈';
        });
    </script>
</body>
</html>
