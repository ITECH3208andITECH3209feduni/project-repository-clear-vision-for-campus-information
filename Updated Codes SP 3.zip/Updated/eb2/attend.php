<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eb1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['event_id']) && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone'])) {
    $event_id = intval($_POST['event_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);

    // Check if the event has available seats
    $checkSeatsSql = "SELECT available_seats FROM events WHERE id = $event_id";
    $result = $conn->query($checkSeatsSql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['available_seats'] > 0) {
            // Insert the booking
            $insertSql = "INSERT INTO bookings (event_id, name, email, phone) VALUES ($event_id, '$name', '$email', '$phone')";
            if ($conn->query($insertSql) === TRUE) {
                // Update the available seats
                $updateSeatsSql = "UPDATE events SET available_seats = available_seats - 1 WHERE id = $event_id";
                if ($conn->query($updateSeatsSql) === TRUE) {
                    header("Location: confirmation.php?event_id=$event_id&name=" . urlencode($name));
                    exit();
                } else {
                    echo "Error updating seats: " . $conn->error;
                }
            } else {
                echo "Error making booking: " . $conn->error;
            }
        } else {
            echo "No available seats for this event.";
        }
    } else {
        echo "Event not found.";
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
