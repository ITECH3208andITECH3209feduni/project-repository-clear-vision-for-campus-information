<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eb1";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, date, location, time,description, available_seats FROM events";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IIE (International Institute Of Education) | Home</title>
    <link rel="shortcut icon" href="images/icon.png" type="image/png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 20px;
            padding: 2px;
            font-size: 1.1em;
        }
        .grid-item {
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            background-color: #f9f9f9;
            background-image: url('https://miro.medium.com/v2/resize:fit:1400/1*xnF9lZjZZTfDA2HsXNDXpw.png'); /* Add your background image path here */
            background-size: cover;
            background-position: center;
            color: white; /* Adjust text color for readability */
            text-shadow: 1px 1px 2px black; /* Add text shadow for better readability */
            height: 600px;

           .grid-item label {
            font-weight: bolder; /* Make label text bolder */
            display: block;
            margin-bottom: 5px;
        }
        .grid-item input[type='submit'] {
            margin-top: 10px;
            padding: 10000px 1000px; /* Increase padding for a larger button */
            background-color: #007bff;
            color: grey;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold; /* Make button text bold */
            font-size: 1.5em; /* Increase the font size of the button text */
        }
        .grid-item input[type='submit']:hover {
            background-color: #0056b3;
        }

        h1 {
            text-align: left;
            font-size: 3em;
            font-weight: bolder; /* Make heading bolder */
        }
        h2 {
            text-align: left;
            font-size: 2em;
            font-weight: bolder; /* Make heading bolder */
        }
        .popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border: 2px solid #007bff;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            text-align: center;
        }
        .popup button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
</style>
<script>
        function showPopup() {
            document.getElementById('popup').style.display = 'block';
        }
        function closePopup() {
            document.getElementById('popup').style.display = 'none';
        }
    </script>
</head>
<body>
    <header>
        <div class="header-icons-container">
            <div class="header-icons">
                <!-- Staff Portal Icon -->
                <div class="icon">
                    <a href="staff-portal.html">
                        <i class="fas fa-users"></i>
                        <span>Staffs</span>
                    </a>
                </div>
                
                <!-- Student Portal Icon -->
                <div class="icon">
                    <a href="student-portal.html">
                        <i class="fas fa-user-graduate"></i>
                        <span>Students</span>
                    </a>
                </div>
                
                <!-- Campus Map Icon -->
                <div class="icon">
                    <a href="https://viewer.mapme.com/ceee2501-6bba-4407-88e5-5edab0fce542" target="_blank">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Location</span>
                    </a>
                </div>
                
                <!-- Search Bar -->
                <div class="search-bar">
                    <input type="text" id="searchInput" placeholder="Search...">
                    <button type="button" id="searchButton">Search</button>
                </div>
            </div>
        </div>
    </header>
    <nav class="navbar">
    <div class="nav-container">
        <div class="logo">
            <a href="index.html"><img src="images/logo.png" alt="IIE Logo"></a>
        </div>
        <div class="hamburger-menu">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
        <ul class="menu">
            <li><a href="index.html">Home</a></li>
            <li class="dropdown">
                <a href="#">About Us</a>
                <div class="dropdown-content">
                    <a href="welcome.html">Welcome Message</a>
                    <a href="why-study-at-iie.html">Why Study At IIE?</a>
                    <a href="our-values.html">Our Values</a>
                    <a href="representatives.html">Representatives</a>
                    <a href="contact.html">Contact</a>
                </div>
            </li>
            <li><a href="events.html">Events</a></li>
            <li class="dropdown">
                <a href="index.php">Courses</a>
                <div class="dropdown-content">
                    <div class="submenu">
                        <a href="international-courses.html">International Student</a>
                        <div class="submenu-content">
                            <a href="#">Accounting</a>
                            <a href="#">Community Service</a>
                            <a href="#">Early Childhood Education</a>
                            <a href="#">Health And Science</a>
                            <a href="#">Hospitality Management</a>
                            <a href="#">Information Technology</a>
                            <a href="#">Management</a>
                        </div>
                    </div>
                    <div class="submenu">
                        <a href="domestic-courses.html">Domestic Student</a>
                        <div class="submenu-content">
                            <a href="#">Accounting</a>
                            <a href="#">Community Services</a>
                            <a href="#">Early Childhood Education</a>
                            <a href="#">Health And Science</a>
                            <a href="#">Hospitality Management</a>
                            <a href="#">Information Technology</a>
                            <a href="#">Management</a>
                        </div>
                    </div>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Resources</a>
                <div class="dropdown-content">
                    <a href="handbook.html">Handbook</a>
                    <a href="student-portal-login.html">Student Portal Login</a>
                    <a href="e-learning.html">E-Learning</a>
                    <a href="overseas-student-health-cover.html">Overseas Student Health Cover</a>
                    <a href="service-and-facility.html">Service And Facility</a>
                    <a href="living-in-australia.html">Living In Australia</a>
                    <a href="payment-options.html">Payment Options</a>
                    <a href="study-pay-payment-plan.html">Study Pay Payment Plan</a>
                </div>
            </li>
            <li><a href="contact.html">Contact Us</a></li>
        </ul>
    </div>
</nav>

<h1></h1>
    <div class="grid-container">
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<div class='grid-item'>";
            echo "<form method='get' action='attend.php'>";
            echo "<h1>" . $row["name"] . "</h1><br>";
            echo "<label>Date: " . $row["date"] . "</label><br>";
            echo "<label>Time: " . $row["time"] . "</label><br>";
            echo "<label>Location: " . $row["location"] . "</label><br>";
            echo "<label>About event: " . $row["description"] . "</label><br>";
            echo "<label>Available seats: " . $row["available_seats"] . "</label><br>";
            echo "<input type='hidden' name='event_id' value='" . $row["id"] . "'>";
            echo "<input type='submit' value='Book'>";
            echo "</form>";
            echo "</div>";
        }
    } else {
        echo "<p>No events found</p>";
    }
    $conn->close();
    ?>
    </div>
    <br>
    <br>


<!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-section contact-info">
                <h3>Contact Us</h3>
                <p>International Institute of Education- IIE</p>
                <p>Level 1 16-18 Wentworth Street, Parramatta, NSW, 2150, Australia</p>
                <p>Phone: +61 (02) 88972125</p>
                <p>Email: info@iie.edu.au</p>
            </div>
            
            <div class="footer-section useful-links">
                <h3>Useful Links</h3>
                <ul>
                    <li><a href="#">Department of Home Affairs</a></li>
                    <li><a href="#">Department of Education</a></li>
                    <li><a href="#">Study Australia</a></li>
                    <li><a href="#">ASQA</a></li>
                    <li><a href="#">Commonwealth Ombudsman</a></li>
                </ul>
            </div>
            
            <div class="footer-section about-us">
                <h3>About Us</h3>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Why Study at IIE?</a></li>
                    <li><a href="#">Our Values</a></li>
                    <li><a href="#">Representatives</a></li>
                </ul>
            </div>
            
            <div class="footer-section online-forms">
                <h3>Online Forms</h3>
                <ul>
                    <li><a href="#">Agent Application</a></li>
                    <li><a href="#">International Student Enrolment</a></li>
                    <li><a href="#">ID Card Request</a></li>
                    <li><a href="#">Refund Request Application</a></li>
                    <li><a href="#">Student Document Request Form</a></li>
                </ul>
            </div>
            
            <div class="footer-section additional-links">
                <h3>Additional Links</h3>
                <ul>
                    <li><a href="#">Staff Login</a></li>
                    <li><a href="#">Partner Login</a></li>
                </ul>
                <p>&copy; International Institute of Education | RTO No: 45150 CRICOS: 03838G |</p>
            </div>
        </div>
    </footer>
</body>
</html>