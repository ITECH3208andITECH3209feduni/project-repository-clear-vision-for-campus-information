<?php include 'header.php'; ?>
    <div class="jumbotron">
        <h1 class="display-4">Welcome to the College Resource Booking System</h1>
        <p class="lead">Book classrooms, labs, and equipment easily.</p>
        <hr class="my-4">
        <p>Select a resource type to get started.</p>
        <a class="btn btn-primary btn-lg" href="classes.php" role="button">Book Classrooms</a>
        <a class="btn btn-secondary btn-lg" href="labs.php" role="button">Book Labs</a>
        <a class="btn btn-success btn-lg" href="equipment.php" role="button">Book Equipment</a>
    </div>
<?php include 'footer.php'; ?>
