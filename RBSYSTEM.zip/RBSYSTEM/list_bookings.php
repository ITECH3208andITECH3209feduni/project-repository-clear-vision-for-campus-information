<?php
include 'db.php';

$sql = "SELECT bookings.id, resources.name as resource_name, users.name as user_name, bookings.start_time, bookings.end_time, bookings.status
        FROM bookings
        JOIN resources ON bookings.resource_id = resources.id
        JOIN users ON bookings.user_id = users.id";
$result = $conn->query($sql);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        $booking_id = $_POST['booking_id'];
        $delete_sql = "DELETE FROM bookings WHERE id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
        header("Location: list_bookings.php"); // Redirect to avoid form resubmission
        exit();
    } elseif (isset($_POST['update'])) {
        $booking_id = $_POST['booking_id'];
        $new_start_time = $_POST['start_time'];
        $new_end_time = $_POST['end_time'];
        $update_sql = "UPDATE bookings SET start_time = ?, end_time = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("ssi", $new_start_time, $new_end_time, $booking_id);
        $stmt->execute();
        header("Location: list_bookings.php"); // Redirect to avoid form resubmission
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking List</title>
    <link rel="stylesheet" href="rbstyle.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 1em;
            font-family: Arial, sans-serif;
            text-align: left;
        }

        table th, table td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        button {
            padding: 5px 10px;
            margin: 2px;
            cursor: pointer;
        }

        .modify-btn {
            background-color: #007bff;
            color: white;
            border: none;
        }

        .save-btn, .cancel-btn {
            background-color: #28a745;
            color: white;
            border: none;
            display: none;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
        }

        .flatpickr-calendar {
            z-index: 9999;
        }
    </style>
</head>
<body>
    <header>
        <h1>Booking List</h1>
    </header>
    <main>
        <h2>Current Bookings</h2>
        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Resource</th>
                        <th>Booked by</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <form method="POST" action="">
                                <td><?php echo htmlspecialchars($row["resource_name"]); ?></td>
                                <td><?php echo htmlspecialchars($row["user_name"]); ?></td>
                                <td>
                                    <input type="text" name="start_time" value="<?php echo htmlspecialchars($row["start_time"]); ?>" class="flatpickr" disabled>
                                </td>
                                <td>
                                    <input type="text" name="end_time" value="<?php echo htmlspecialchars($row["end_time"]); ?>" class="flatpickr" disabled>
                                </td>
                                <td><?php echo htmlspecialchars($row["status"]); ?></td>
                                <td>
                                    <input type="hidden" name="booking_id" value="<?php echo intval($row["id"]); ?>">
                                    <button type="button" class="modify-btn">Modify</button>
                                    <button type="submit" name="update" class="save-btn">Save</button>
                                    <button type="button" class="cancel-btn">Cancel</button>
                                    <button type="submit" name="delete" class="delete-btn" onclick="return confirm('Are you sure you want to delete this booking?');">Delete</button>
                                </td>
                            </form>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No bookings found.</p>
        <?php endif; ?>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            flatpickr(".flatpickr", {
                enableTime: true,
                dateFormat: "Y-m-d H:i",
            });

            // Handle the Modify button functionality
            document.querySelectorAll('.modify-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const form = button.closest('form');
                    const startTimeInput = form.querySelector('[name="start_time"]');
                    const endTimeInput = form.querySelector('[name="end_time"]');
                    const saveButton = form.querySelector('.save-btn');
                    const cancelButton = form.querySelector('.cancel-btn');

                    startTimeInput.disabled = false;
                    endTimeInput.disabled = false;
                    saveButton.style.display = 'inline-block';
                    cancelButton.style.display = 'inline-block';
                    button.style.display = 'none';

                    startTimeInput.dataset.originalValue = startTimeInput.value;
                    endTimeInput.dataset.originalValue = endTimeInput.value;
                });
            });

            // Handle the Cancel button functionality
            document.querySelectorAll('.cancel-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const form = button.closest('form');
                    const startTimeInput = form.querySelector('[name="start_time"]');
                    const endTimeInput = form.querySelector('[name="end_time"]');
                    const modifyButton = form.querySelector('.modify-btn');
                    const saveButton = form.querySelector('.save-btn');

                    startTimeInput.value = startTimeInput.dataset.originalValue;
                    endTimeInput.value = endTimeInput.dataset.originalValue;

                    startTimeInput.disabled = true;
                    endTimeInput.disabled = true;
                    saveButton.style.display = 'none';
                    button.style.display = 'none';
                    modifyButton.style.display = 'inline-block';
                });
            });
        });
    </script>
</body>
</html>
