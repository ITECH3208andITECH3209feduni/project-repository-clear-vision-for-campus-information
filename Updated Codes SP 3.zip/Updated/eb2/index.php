<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eb1";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, date, location, time, description, available_seats FROM events";
$result = $conn->query($sql);

// Associative array to map event names to image paths
$imagePaths = [
    "Astrophysics" => "images/planet.jpg",
    "Food Festival" => "images/food.jpg",
    "Basketball Tournament" => "images/basketball.jpg",
    // Add more event names and their corresponding image paths here
];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IIE (International Institute Of Education) | Home</title>
    <link rel="shortcut icon" href="images/icon.png" type="image/png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    .grid-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        padding: 20px;
        font-size: 1.1em;
    }
    .grid-item {
        border: 1px solid #ccc;
        padding: 20px;
        border-radius: 5px;
        background-color: #f9f9f9;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    .grid-item img {
        width: 100%;
        height: auto;
        max-height: 200px;
        object-fit: cover;
        border-radius: 5px;
    }
    .grid-item h1 {
        font-size: 1.5em;
        margin: 10px 0;
    }
    .grid-item p {
        margin: 5px 0;
    }
    .grid-item a {
        margin-top: 10px;
        padding: 10px 20px;
        background-color: #007bff;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        font-size: 1em;
    }
    .grid-item a:hover {
        background-color: #0056b3;
    }
    </style>
</head>
<body>
    <header>
        <div class="header-icons-container">
            <div class="header-icons">
                <!-- Staff Portal Icon -->
                <div class="icon">
                    <a href="staff-portal.html">
                        <i class="fas fa-users"></i>
                        <span>Staffs</span>
                    </a>
                </div>
                
                <!-- Student Portal Icon -->
                <div class="icon">
                    <a href="student-portal.html">
                        <i class="fas fa-user-graduate"></i>
                        <span>Students</span>
                    </a>
                </div>
                
                <!-- Campus Map Icon -->
                <div class="icon">
                    <a href="https://viewer.mapme.com/ceee2501-6bba-4407-88e5-5edab0fce542" target="_blank">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Location</span>
                    </a>
                </div>
                
                <!-- Search Bar -->
                <div class="search-bar">
                    <input type="text" id="searchInput" placeholder="Search...">
                    <button type="button" id="searchButton">Search</button>
                </div>
            </div>
        </div>
    </header>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="index.html"><img src="images/logo.png" alt="IIE Logo"></a>
            </div>
            <div class="hamburger-menu">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
            </div>
            <ul class="menu">
                <li><a href="updated/index.php">Home</a></li>
                <li class="dropdown">
                    <a href="#">About Us</a>
                    <div class="dropdown-content">
                        <a href="welcome.html">Welcome Message</a>
                        <a href="why-study-at-iie.html">Why Study At IIE?</a>
                        <a href="our-values.html">Our Values</a>
                        <a href="representatives.html">Representatives</a>
                        <a href="contact.html">Contact</a>
                    </div>
                </li>
                <li><a href="events.html">Events</a></li>
                <li class="dropdown">
                    <a href="index.php">Courses</a>
                    <div class="dropdown-content">
                        <div class="submenu">
                            <a href="international-courses.html">International Student</a>
                            <div class="submenu-content">
                                <a href="#">Accounting</a>
                                <a href="#">Community Service</a>
                                <a href="#">Early Childhood Education</a>
                                <a href="#">Health And Science</a>
                                <a href="#">Hospitality Management</a>
                                <a href="#">Information Technology</a>
                                <a href="#">Management</a>
                            </div>
                        </div>
                        <div class="submenu">
                            <a href="domestic-courses.html">Domestic Student</a>
                            <div class="submenu-content">
                                <a href="#">Accounting</a>
                                <a href="#">Community Services</a>
                                <a href="#">Early Childhood Education</a>
                                <a href="#">Health And Science</a>
                                <a href="#">Hospitality Management</a>
                                <a href="#">Information Technology</a>
                                <a href="#">Management</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="dropdown">
                    <a href="#">Resources</a>
                    <div class="dropdown-content">
                        <a href="handbook.html">Handbook</a>
                        <a href="student-portal-login.html">Student Portal Login</a>
                        <a href="e-learning.html">E-Learning</a>
                        <a href="overseas-student-health-cover.html">Overseas Student Health Cover</a>
                        <a href="service-and-facility.html">Service And Facility</a>
                        <a href="living-in-australia.html">Living In Australia</a>
                        <a href="payment-options.html">Payment Options</a>
                        <a href="study-pay-payment-plan.html">Study Pay Payment Plan</a>
                    </div>
                </li>
                <li><a href="contact.html">Contact Us</a></li>
            </ul>
        </div>
    </nav>

    <div class="grid-container">
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $imagePath = isset($imagePaths[$row["name"]]) ? $imagePaths[$row["name"]] : "images/default.jpg";
            echo "<div class='grid-item'>";
            echo "<img src='$imagePath' alt='" . $row["name"] . "'>";
            echo "<h1>" . $row["name"] . "</h1>";
            echo "<p><strong>Date:</strong> " . $row["date"] . "</p>";
            echo "<p><strong>Time:</strong> " . $row["time"] . "</p>";
            echo "<p><strong>Location:</strong> " . $row["location"] . "</p>";
            echo "<p><strong>About event:</strong> " . $row["description"] . "</p>";
            echo "<p><strong>Available seats:</strong> <span id='seats_" . $row["id"] . "'>" . $row["available_seats"] . "</span></p>";
            echo "<a href='booking_form.php?event_id=" . $row["id"] . "'>Book</a>";
            echo "</div>";
        }
    } else {
        echo "<p>No events found</p>";
    }
    $conn->close();
    ?>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-section contact-info">
                <h3>Contact Us</h3>
                <p>International Institute of Education- IIE</p>
                <p>Level 1 16-18 Wentworth Street, Parramatta, NSW, 2150, Australia</p>
                <p>Phone: +61 (02) 88972125</p>
                <p>Email: info@iie.edu.au</p>
            </div>
            
            <div class="footer-section useful-links">
                <h3>Useful Links</h3>
                <ul>
                    <li><a href="#">Department of Home Affairs</a></li>
                    <li><a href="#">Department of Education</a></li>
                    <li><a href="#">Study Australia</a></li>
                    <li><a href="#">ASQA</a></li>
                    <li><a href="#">Commonwealth Ombudsman</a></li>
                </ul>
            </div>
            
            <div class="footer-section about-us">
                <h3>About Us</h3>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Why Study at IIE?</a></li>
                    <li><a href="#">Our Values</a></li>
                    <li><a href="#">Representatives</a></li>
                </ul>
            </div>
            
            <div class="footer-section online-forms">
                <h3>Online Forms</h3>
                <ul>
                    <li><a href="#">Agent Application</a></li>
                    <li><a href="#">International Student Enrolment</a></li>
                    <li><a href="#">ID Card Request</a></li>
                    <li><a href="#">Refund Request Application</a></li>
                    <li><a href="#">Student Document Request Form</a></li>
                </ul>
            </div>
            
            <div class="footer-section additional-links">
                <h3>Additional Links</h3>
                <ul>
                    <li><a href="#">Staff Login</a></li>
                    <li><a href="#">Partner Login</a></li>
                </ul>
                <p>&copy; International Institute of Education | RTO No: 45150 CRICOS: 03838G |</p>
            </div>
        </div>
    </footer>
</body>
</html>
