<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>
<body>
    <!-- Main Content -->
    <main>
        <!-- Image below navbar -->
        <section class="hero-section">
            <div class="hero-overlay">
                <h1>Welcome to the International Institute of Education</h1>
                <p>Empowering students to achieve their academic and career goals</p>
                <a href="application form/index.php" class="hero-cta">Register Now</a>
            </div>
        </section>
        
        
        <!-- Quote Section -->
        <section class="quote-section">
            <div class="container">
                <div class="quote-container">
                    <div class="quote-text">
                        <p>"Education is not the filling of a pail, but the lighting of a fire." - William Butler Yeats</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Image Content Sections -->
        <div class="ic-container">
            <!-- First Image Content Section -->
            <div class="image-content-container">
                <section class="image-content-section">
                    <div class="image">
                        <img src="images/learningsupport.jpg" alt="LearningSupport">
                    </div>
                    <div class="content">
                        <h2>Why IIE?</h2>
                        <p>At the International Institute of Education (IIE), we empower our students to unlock their full potential and achieve their academic and career goals. With a diverse range of courses, experienced faculty, and state-of-the-art facilities, we provide a transformative educational experience that prepares you for success in the modern world.</p>
                        <a href="about.html" class="cta">Learn More</a>
                    </div>
                </section>
            </div>

            <!-- Second Image Content Section -->
            <div class="image-content-container">
                <section class="image-content-section">
                    <div class="image">
                        <img src="images/registration.jpg" alt="Registration">
                    </div>
                    <div class="content">
                        <h2>Register Now</h2>
                        <p>Ready to take the next step in your educational journey? Registration is now open at the International Institute of Education (IIE)! Seize this opportunity to join a dynamic community of learners and gain access to world-class education that prepares you for the challenges and opportunities of tomorrow.</p>
                        <a href="application form/index.php" class="cta">Register</a>
                    </div>
                </section>
            </div>
        </div>

      <!-- Our Courses Section -->
<section class="our-courses">
    <h2>Our Courses</h2>
    <div class="container-courses">
        <div class="card">
            <img src="images/it.jpg" alt="Information Technology">
            <div class="overlay"></div>
            <div class="course-name">Information Technology</div>
        </div>
        <div class="card">
            <img src="images/accounting.png" alt="Accounting">
            <div class="overlay"></div>
            <div class="course-name">Accounting</div>
        </div>
        <div class="card">
            <img src="images/finance.jpg" alt="Finance">
            <div class="overlay"></div>
            <div class="course-name">Finance</div>
        </div>
        <div class="card">
            <img src="images/childhood.jpg" alt="Early Childhood Education">
            <div class="overlay"></div>
            <div class="course-name">Early Childhood Education</div>
        </div>
        <div class="card">
            <img src="images/community.jpg" alt="Community Services">
            <div class="overlay"></div>
            <div class="course-name">Community Services</div>
        </div>
        <div class="card">
            <img src="images/management.jpg" alt="Management">
            <div class="overlay"></div>
            <div class="course-name">Management</div>
        </div>
    </div>
</section>

        <!-- News and Events Section -->
        <div class="news-events">
            <!-- Latest News -->
            <div class="news">
                <h2>Latest News</h2>
                <div class="container-news">
                    <!-- News Articles -->
                    <section class="news-article">
                        <img src="images/visanews.jpg" alt="News 1">
                        <div class="news-description">
                            <h3>Immigration Meeting</h3>
                            <p>Join us for an important immigration meeting to discuss the latest updates and opportunities for international students.</p>
                            <a href="news.html">Read More</a>
                        </div>
                    </section>
                    <section class="news-article">
                        <img src="images/covidnews.jpg" alt="News 2">
                        <div class="news-description">
                            <h3>COVID Hits Again</h3>
                            <p>Stay informed about the latest developments regarding COVID-19 as it continues to impact our communities.</p>
                            <a href="news.html">Read More</a>
                        </div>
                    </section>
                </div>
            </div>
            
            <!-- Upcoming Events -->
            <div class="events">
                <h2>Upcoming Events</h2>
                <div class="event">
                    <img src="images/fun.jpg" alt="Event 1">
                    <div class="event-details">
                        <a href="events.html">
                            <h3>Event 1 Title</h3>
                        </a>
                        <p>Date: January 1, 2025</p>
                        <p>Location: Venue 1</p>
                    </div>
                </div>
                <div class="event">
                    <img src="images/person.jpg" alt="Event 2">
                    <div class="event-details">
                        <a href="events.html">
                            <h3>Event 2 Title</h3>
                        </a>
                        <p>Date: February 15, 2025</p>
                        <p>Location: Venue 2</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Feedback Section -->
        <div class="container-feedback">
            <a href="Inquery Form/index.php">
                <h2>Any Enquiries?</h2>
            </a>
        </div>
    </main>
   <!-- Footer -->
<footer>
    <div class="container">
        <div class="footer-section contact-info">
            <h3>Contact Us</h3>
            <p>International Institute of Education- IIE</p>
            <p>Level 1 16-18 Wentworth Street, Parramatta, NSW, 2150, Australia</p>
            <p>Phone: +61 (02) 88972125</p>
            <p>Email: info@iie.edu.au</p>
        </div>
        
        <div class="footer-section useful-links">
            <h3>Useful Links</h3>
            <ul>
                <li><a href="#">Department of Home Affairs</a></li>
                <li><a href="#">Department of Education</a></li>
                <li><a href="#">Study Australia</a></li>
                <li><a href="#">ASQA</a></li>
                <li><a href="#">Commonwealth Ombudsman</a></li>
            </ul>
        </div>
        
        <div class="footer-section about-us">
            <h3>About Us</h3>
            <ul>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Why Study at IIE?</a></li>
                <li><a href="#">Our Values</a></li>
                <li><a href="#">Representatives</a></li>
            </ul>
        </div>
        
        <div class="footer-section online-forms">
            <h3>Online Forms</h3>
            <ul>
                <li><a href="#">Agent Application</a></li>
                <li><a href="#">International Student Enrolment</a></li>
                <li><a href="#">ID Card Request</a></li>
                <li><a href="#">Refund Request Application</a></li>
                <li><a href="#">Student Document Request Form</a></li>
            </ul>
        </div>
        
        <div class="footer-section additional-links">
            <h3>Additional Links</h3>
            <ul>
                <li><a href="#">Staff Login</a></li>
                <li><a href="#">Partner Login</a></li>
            </ul>
            <p>&copy; International Institute of Education | RTO No: 45150 CRICOS: 03838G |</p>
        </div>
    </div>
</footer>
   
    <!-- JavaScript File -->
 <!-- JavaScript File -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menuBtn = document.querySelector('.hamburger-menu');
            const menu = document.querySelector('.menu');

            menuBtn.addEventListener('click', function () {
                menu.classList.toggle('show');
            });
        });
    </script>

<script>



</body>
</html>
