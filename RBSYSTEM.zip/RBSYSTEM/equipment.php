<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Update booking status
include 'update_booking_status.php';

$role = $_SESSION['role'];

$sql = "SELECT r.id, r.name, r.description, r.quantity, r.image,
               COUNT(b.id) as booked_slots,
               GREATEST((r.quantity - COUNT(b.id)), 0) as available_slots
        FROM resources r
        LEFT JOIN bookings b ON r.id = b.resource_id AND b.status = 'booked'
        WHERE r.type = 'equipment'
        GROUP BY r.id, r.name, r.description, r.quantity, r.image";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>
    <main>
        <h2>Available Equipment</h2>
        <div class="grid-container">
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="resource-card">
                        <img src="images/<?php echo $row["image"]; ?>" alt="<?php echo $row["name"]; ?>" class="resource-image">
                        <h3><?php echo $row["name"]; ?></h3>
                        <p><strong>Description:</strong> <?php echo $row["description"]; ?></p>
                        <p><strong>Quantity:</strong> <?php echo $row["quantity"]; ?></p>
                        <p>
                            <?php if ($row["available_slots"] > 0): ?>
                                <a href="book_resourceequipment.php?resource_id=<?php echo $row['id']; ?>">Book</a>
                            <?php else: ?>
                                <button disabled>No Available Slots</button>
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No equipment found.</p>
            <?php endif; ?>
        </div>
    </main>
    <?php include 'footer.php'; ?> 
</body>
</html>
