<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_name = isset($_SESSION['name']) ? $_SESSION['name'] : 'Guest';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resource Booking Dashboard</title>
    <link rel="stylesheet" href="rbstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header>
    <div class="header-icons-container">
        <div class="header-icons">
            <!-- Student Portal Icon -->
            <div class="icon left-icon">
                <a href="register.php">
                    <i class="fas fa-user-graduate fa-2x"></i>
                </a>
            </div>

            <!-- User Name -->
            <div class="username">
                <span>Welcome, <?php echo htmlspecialchars($user_name); ?></span>
            </div>

            <!-- LogOut Icon -->
            <div class="icon right-icon">
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </div>
</header>

<nav class="navbar">
    <div class="nav-container">
        <div class="logo">
            <a href="index.php"><img src="../Updated/images/logo.png" alt="IIE Logo"></a>
        </div>
        <div class="hamburger-menu" id="hamburger-menu">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
        <ul class="menu" id="menu">
            <li><a href="index.php">Home</a></li>
            <li class="dropdown">
                <a href="#">About Us</a>
                <div class="dropdown-content">
                    <a href="welcome.html">Welcome Message</a>
                    <a href="why-study-at-iie.html">Why Study At IIE?</a>
                    <a href="our-values.html">Our Values</a>
                    <a href="representatives.html">Representatives</a>
                    <a href="contact.html">Contact</a>
                </div>
            </li>
            <li><a href="events.html">Events</a></li>
            <li class="dropdown">
                <a href="#">Courses</a>
                <div class="dropdown-content">
                    <div class="submenu">
                        <a href="international-courses.html">International Student</a>
                        <div class="submenu-content">
                            <a href="#">Accounting</a>
                            <a href="#">Community Service</a>
                            <a href="#">Early Childhood Education</a>
                            <a href="#">Health And Science</a>
                            <a href="#">Hospitality Management</a>
                            <a href="#">Information Technology</a>
                            <a href="#">Management</a>
                        </div>
                    </div>
                    <div class="submenu">
                        <a href="domestic-courses.html">Domestic Student</a>
                        <div class="submenu-content">
                            <a href="#">Accounting</a>
                            <a href="#">Community Services</a>
                            <a href="#">Early Childhood Education</a>
                            <a href="#">Health And Science</a>
                            <a href="#">Hospitality Management</a>
                            <a href="#">Information Technology</a>
                            <a href="#">Management</a>
                        </div>
                    </div>
                </div>
            </li>
            <li class="dropdown">
                <a href="#">Resources</a>
                <div class="dropdown-content">
                    <a href="handbook.html">Handbook</a>
                    <a href="student-portal-login.html">Student Portal Login</a>
                    <a href="e-learning.html">E-Learning</a>
                    <a href="overseas-student-health-cover.html">Overseas Student Health Cover</a>
                    <a href="service-and-facility.html">Service And Facility</a>
                    <a href="living-in-australia.html">Living In Australia</a>
                    <a href="payment-options.html">Payment Options</a>
                    <a href="study-pay-payment-plan.html">Study Pay Payment Plan</a>
                </div>
            </li>
            <li><a href="contact.html">Contact Us</a></li>
        </ul>
    </div>
</nav>