<!DOCTYPE html>
<html>
<head>
    <title>College Admissions Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <img src="logo.png" alt="College Logo" class="logo">
        <h2>College Admissions Form</h2>
        <p>Enter your admission information below</p>
        <form id="admissionForm" action="application.php" method="post">
            <h3>Name</h3>
            <label>First Name <span class="required">*</span></label>
            <input type="text" name="first_name" required><br>
            <label>Middle Initial (optional)</label>
            <input type="text" name="middle_initial"><br>
            <label>Last Name <span class="required">*</span></label>
            <input type="text" name="last_name" required><br>

            <h3>Birth Date <span class="required">*</span></h3>
            <label>Month</label>
            <select name="birth_month" id="birth_month" required></select>
            <label>Day</label>
            <select name="birth_day" id="birth_day" required></select>
            <label>Year</label>
            <select name="birth_year" id="birth_year" required></select><br>

            <h3>Gender <span class="required">*</span></h3>
            <label>
                <input type="radio" name="gender" value="Male" required> Male
            </label>
            <label>
                <input type="radio" name="gender" value="Female" required> Female
            </label><br>

            <h3>Citizenship <span class="required">*</span></h3>
            <select name="citizenship" id="citizenship" required></select><br>

            <h3>Contact Details</h3>
            <label>Phone <span class="required">*</span></label>
            <input type="text" name="phone" required><br>
            <label>Email Address <span class="required">*</span></label>
            <input type="email" name="email" required><br>

            <h3>Mailing Address</h3>
            <label>Street Address <span class="required">*</span></label>
            <input type="text" name="street_address" required><br>
            <label>Street Address Line 2 (optional)</label>
            <input type="text" name="street_address_line2"><br>
            <label>City <span class="required">*</span></label>
            <input type="text" name="city" required><br>
            <label>State / Province <span class="required">*</span></label>
            <input type="text" name="state_province" required><br>
            <label>Postal / Zip Code <span class="required">*</span></label>
            <input type="text" name="postal_zip_code" required><br>

            <h3>Emergency Contact</h3>
            <label>First Name <span class="required">*</span></label>
            <input type="text" name="emergency_first_name" required><br>
            <label>Last Name <span class="required">*</span></label>
            <input type="text" name="emergency_last_name" required><br>
            <label>Relationship <span class="required">*</span></label>
            <input type="text" name="relationship" required><br>
            <label>Email <span class="required">*</span></label>
            <input type="email" name="emergency_email" required><br>
            <label>Phone Number <span class="required">*</span></label>
            <input type="text" name="emergency_phone" required><br>

            <h3>Languages (optional)</h3>
            <label>Do you speak any languages other than English?</label>
            <input type="text" name="other_languages"><br>

            <button type="submit">Submit Application</button>
        </form>
    </div>

    <script>
        // Populate the date fields
        window.onload = function() {
            // Populate months
            const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            const birthMonth = document.getElementById('birth_month');
            months.forEach(month => {
                let option = document.createElement('option');
                option.value = month;
                option.textContent = month;
                birthMonth.appendChild(option);
            });

            // Populate days
            const birthDay = document.getElementById('birth_day');
            for (let i = 1; i <= 31; i++) {
                let option = document.createElement('option');
                option.value = i;
                option.textContent = i;
                birthDay.appendChild(option);
            }

            // Populate years
            const birthYear = document.getElementById('birth_year');
            const currentYear = new Date().getFullYear();
            for (let i = currentYear; i >= 1900; i--) {
                let option = document.createElement('option');
                option.value = i;
                option.textContent = i;
                birthYear.appendChild(option);
            }

            // Populate countries
            const citizenship = document.getElementById('citizenship');
            const countries = ["USA", "Canada", "UK", "Australia", "Pakistan", "Nepal", "India", "China", "France", "Germany", "Italy", "Japan"];
            countries.forEach(country => {
                let option = document.createElement('option');
                option.value = country;
                option.textContent = country;
                citizenship.appendChild(option);
            });
        }
    </script>
</body>
</html>
