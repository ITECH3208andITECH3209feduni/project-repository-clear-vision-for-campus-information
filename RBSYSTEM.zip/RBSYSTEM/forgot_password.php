<?php
include 'db.php';
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $sql = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $sql->bind_param("s", $email);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        // Generate a unique token
        $token = bin2hex(random_bytes(50));

        // Store the token in the database with an expiration date (e.g., 1 hour from now)
        $expires = date("U") + 3600;
        $user = $result->fetch_assoc();
        $user_id = $user['id'];

        $sql = "INSERT INTO password_reset (user_id, token, expires) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $user_id, $token, $expires);
        $stmt->execute();

        // Create reset URL
        $reset_url = "http://yourwebsite.com/reset_password.php?token=" . $token;

        // Send the reset URL to the user's email using PHPMailer
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = 0;                                      // Disable verbose debug output
            $mail->isSMTP();                                           // Set mailer to use SMTP
            $mail->Host       = 'smtp.gmail.com';                      // Specify main and backup SMTP servers
            $mail->SMTPAuth   = true;                                  // Enable SMTP authentication
            $mail->Username   = 'panthianand49@gmail.com';                // SMTP username
            $mail->Password   = 'Science#12';                 // SMTP password
            $mail->SMTPSecure = 'tls';                                 // Enable TLS encryption, `ssl` also accepted
            $mail->Port       = 587;                                   // TCP port to connect to

            //Recipients
            $mail->setFrom('panthianand@gmail.com', 'Your Website Name');
            $mail->addAddress($email);                                 // Add a recipient

            // Content
            $mail->isHTML(true);                                       // Set email format to HTML
            $mail->Subject = 'Password Reset Request';
            $mail->Body    = "Please click the following link to reset your password: <a href='$reset_url'>$reset_url</a>";
            $mail->AltBody = "Please click the following link to reset your password: $reset_url";

            $mail->send();
            $success = "A password reset link has been sent to your email.";
        } catch (Exception $e) {
            $error = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

    } else {
        $error = "No user found with that email address.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="rbstyle.css">
</head>
<body>
    <div class="login-container">
        <img src="../../Updated/Images/logo.png" alt="College Logo" class="logo">
        <form action="forgot_password.php" method="post">
            <h2>Forgot Password</h2>
            <?php if (!empty($error)): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
            <?php if (!empty($success)): ?>
                <p class="success"><?php echo htmlspecialchars($success); ?></p>
            <?php endif; ?>
            <label>Email</label>
            <input type="email" name="email" placeholder="Enter your email" required><br>
            <button type="submit">Send Reset Link</button>
        </form>
        <div class="back-to-login">
            <a href="login.php">Back to Login</a>
        </div>
    </div>
</body>
</html>
