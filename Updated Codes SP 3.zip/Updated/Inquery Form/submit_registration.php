<?php
$host = 'localhost'; 
$dbname = 'registration_db'; 
$username = 'root'; 
$password = ''; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$dateOfBirth = $_POST['dateOfBirth'];
$email = $_POST['email'];
$phoneNumber = $_POST['phoneNumber'];
$address = $_POST['address'];
$passportNumber = $_POST['passportNumber'];
$course = $_POST['course'];

$query = "INSERT INTO students (firstName, lastName, dateOfBirth, email, phoneNumber, address, passportNumber, course) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("ssssssss", $firstName, $lastName, $dateOfBirth, $email, $phoneNumber, $address, $passportNumber, $course);
$stmt->execute();

if ($stmt->affected_rows === 1) {
    echo "Registration successful!";
} else {
    echo "Error registering: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
