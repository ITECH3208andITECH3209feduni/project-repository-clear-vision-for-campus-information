</main>
<footer>
    <div class="container">
        <div class="footer-section contact-info">
            <h3>Contact Us</h3>
            <p>International Institute of Education- IIE</p>
            <p>Level 1 16-18 Wentworth Street, Parramatta, NSW, 2150, Australia</p>
            <p>Phone: +61 (02) 88972125</p>
            <p>Email: info@iie.edu.au</p>
        </div>
        
        <div class="footer-section useful-links">
            <h3>Useful Links</h3>
            <ul>
                <li><a href="#">Department of Home Affairs</a></li>
                <li><a href="#">Department of Education</a></li>
                <li><a href="#">Study Australia</a></li>
                <li><a href="#">ASQA</a></li>
                <li><a href="#">Commonwealth Ombudsman</a></li>
            </ul>
        </div>
        
        <div class="footer-section about-us">
            <h3>About Us</h3>
            <ul>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Why Study at IIE?</a></li>
                <li><a href="#">Our Values</a></li>
                <li><a href="#">Representatives</a></li>
            </ul>
        </div>
        
        <div class="footer-section online-forms">
            <h3>Online Forms</h3>
            <ul>
                <li><a href="#">Agent Application</a></li>
                <li><a href="#">International Student Enrolment</a></li>
                <li><a href="#">ID Card Request</a></li>
                <li><a href="#">Refund Request Application</a></li>
                <li><a href="#">Student Document Request Form</a></li>
            </ul>
        </div>
        
        <div class="footer-section additional-links">
            <h3>Additional Links</h3>
            <ul>
                <li><a href="#">Staff Login</a></li>
                <li><a href="#">Partner Login</a></li>
            </ul>
            <p>&copy; International Institute of Education | RTO No: 45150 CRICOS: 03838G | </p>
        </div>
    </div>
</footer>
</body>
</html>
