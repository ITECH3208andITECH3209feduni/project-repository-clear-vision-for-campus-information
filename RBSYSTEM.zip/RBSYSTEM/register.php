<?php
include 'db.php';
session_start();

$success_message = "";
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    // Validate email format
    if (strpos($username, '@gmail.com') === false) {
        $error_message = "Username must be a valid Gmail address.";
    } else {
        // Check for duplicate username
        $username_check_sql = "SELECT * FROM users WHERE username = '$username'";
        $username_check_result = $conn->query($username_check_sql);
        if ($username_check_result->num_rows > 0) {
            $error_message = "Username already exists. Please choose a different one.";
        } else {
            // Handle file upload
            $profile_pic = $_FILES['profile_pic'];
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($profile_pic["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            // Check if image file is a actual image or fake image
            $check = getimagesize($profile_pic["tmp_name"]);
            if ($check !== false) {
                $uploadOk = 1;
            } else {
                $error_message = "File is not an image.";
                $uploadOk = 0;
            }

            // Check file size
            if ($profile_pic["size"] > 500000) {
                $error_message = "Sorry, your file is too large.";
                $uploadOk = 0;
            }

            // Allow certain file formats
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $error_message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                $error_message = "Sorry, your file was not uploaded.";
            } else {
                if (move_uploaded_file($profile_pic["tmp_name"], $target_file)) {
                    $sql = "INSERT INTO users (name, username, password, role, profile_pic) VALUES ('$name', '$username', '$password', '$role', '$target_file')";
                    if ($conn->query($sql) === TRUE) {
                        $success_message = "Registration successful!";
                        header("Location: login.php");
                    } else {
                        $error_message = "Error: " . $sql . "<br>" . $conn->error;
                    }
                } else {
                    $error_message = "Sorry, there was an error uploading your file.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="rbstyle.css">
</head>
<body>
    <div class="form-container">
        <h1>Register</h1>
        <?php if (!empty($error_message)): ?>
            <div class="message error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($success_message)): ?>
            <div class="message success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <form method="POST" action="" enctype="multipart/form-data" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="username">Username (must be a valid Gmail address):</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="student">Student</option>
                    <option value="staff">Staff</option>
                </select>
            </div>
            <div class="form-group">
                <label for="profile_pic">Profile Picture:</label>
                <input type="file" id="profile_pic" name="profile_pic" required>
            </div>
            <button type="submit" class="btn">Register</button>
        </form>
    </div>
    <script>
        function validateForm() {
            var username = document.getElementById('username').value;
            if (username.indexOf('@gmail.com') === -1) {
                alert('Username must be a valid Gmail address.');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
